import { useEffect, useState } from "react";
import { getBalances, createAccount, sendPayment, addTrustline } from "../api";
import PaymentForm from "../components/PaymentForm";
import BalanceCard from "../components/BalanceCard";
import TransactionHistory from "../components/TransactionHistory";

export default function Dashboard() {
  const [employer, setEmployer] = useState(null);
  const [freelancer, setFreelancer] = useState(null);
  const [loading, setLoading] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const loadBalances = async () => {
    setLoading(true);
    try {
      if (employer) {
        const bal = await getBalances(employer.publicKey);
        setEmployer((e) => ({ ...e, balances: bal }));
      }
      if (freelancer) {
        const bal = await getBalances(freelancer.publicKey);
        setFreelancer((f) => ({ ...f, balances: bal }));
      }
    } catch (err) {
      console.error('balance load error', err);
    } finally {
      setLoading(false);
      setRefreshKey((k) => k + 1);
    }
  };

  const handleCreate = async (role) => {
    setLoading(true);
    try {
      const res = await createAccount(role);
      if (res.success) {
        await addTrustline(res.secretKey);
        if (role === 'employer') setEmployer(res);
        else setFreelancer(res);
      }
    } catch (err) {
      console.error('create account error', err);
      alert(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBalances();
  }, [employer, freelancer]);

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>💰 FreeLancePay Dashboard</h1>

      <div style={{ marginBottom: '20px' }}>
        <button 
          onClick={() => handleCreate('employer')} 
          disabled={loading || !!employer}
          style={{ marginRight: '10px', padding: '10px 20px', cursor: 'pointer' }}
        >
          {employer ? '✅ Employer Created' : '➕ Create Employer'}
        </button>
        <button 
          onClick={() => handleCreate('freelancer')} 
          disabled={loading || !!freelancer}
          style={{ marginRight: '10px', padding: '10px 20px', cursor: 'pointer' }}
        >
          {freelancer ? '✅ Freelancer Created' : '➕ Create Freelancer'}
        </button>
        <button 
          onClick={loadBalances}
          disabled={loading}
          style={{ padding: '10px 20px', cursor: 'pointer' }}
        >
          {loading ? 'Refreshing...' : '🔄 Refresh'}
        </button>
      </div>

      {loading && <p style={{ color: '#666' }}>⏳ Loading...</p>}

      <PaymentForm
        refresh={loadBalances}
        employer={employer}
        freelancer={freelancer}
      />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginTop: '20px' }}>
        <div>
          <BalanceCard title="Employer" balances={employer?.balances} />
          <TransactionHistory publicKey={employer?.publicKey} forceRefresh={refreshKey} />
        </div>
        <div>
          <BalanceCard title="Freelancer" balances={freelancer?.balances} />
          <TransactionHistory publicKey={freelancer?.publicKey} forceRefresh={refreshKey} />
        </div>
      </div>

      <div style={{ marginTop: '30px', padding: '15px', backgroundColor: '#f5f5f5', borderRadius: '4px', fontSize: '12px' }}>
        <h4>Debug Info</h4>
        <pre style={{ maxHeight: '200px', overflow: 'auto' }}>
          {JSON.stringify({ employer, freelancer }, null, 2)}
        </pre>
      </div>
    </div>
  );
}
