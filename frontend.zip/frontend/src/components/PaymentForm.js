import { useState } from "react";
import { sendPayment } from "../api";

export default function PaymentForm({ refresh, employer, freelancer }) {
  const [amount, setAmount] = useState(10);
  const [memo, setMemo] = useState("work payment");
  const [status, setStatus] = useState("");
  const [sending, setSending] = useState(false);

  const handlePay = async () => {
    if (!employer || !freelancer) {
      setStatus('❌ Create both accounts first');
      return;
    }

    if (!amount || amount <= 0) {
      setStatus('❌ Please enter a valid amount');
      return;
    }

    setSending(true);
    setStatus("⏳ Sending payment...");
    try {
      const res = await sendPayment({
        senderSecret: employer.secretKey,
        receiverPublic: freelancer.publicKey,
        amount: parseFloat(amount),
        memo,
      });

      setStatus(`✅ Success! Tx: ${res.hash.slice(0, 20)}...`);
      setMemo("work payment");
      setAmount(10);
      refresh();
    } catch (err) {
      setStatus(`❌ Payment failed: ${err.message}`);
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div style={{ padding: '15px', border: '2px solid #4CAF50', borderRadius: '4px', marginBottom: '20px', backgroundColor: '#f1f8f4' }}>
      <h3 style={{ marginTop: 0, color: '#2e7d32' }}>💸 Send Payment</h3>
      
      <div style={{ marginBottom: '10px' }}>
        <label style={{ display: 'block', marginBottom: '5px' }}>Amount (USDC):</label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          min="0"
          step="0.01"
          disabled={sending}
          style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
        />
      </div>

      <div style={{ marginBottom: '10px' }}>
        <label style={{ display: 'block', marginBottom: '5px' }}>Memo (optional):</label>
        <input
          type="text"
          value={memo}
          onChange={(e) => setMemo(e.target.value)}
          disabled={sending}
          style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
        />
      </div>

      <button 
        onClick={handlePay}
        disabled={sending || !employer || !freelancer}
        style={{
          width: '100%',
          padding: '10px',
          backgroundColor: '#4CAF50',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: sending ? 'not-allowed' : 'pointer',
          opacity: sending || !employer || !freelancer ? 0.5 : 1
        }}
      >
        {sending ? 'Sending...' : 'Send USDC'}
      </button>

      <p style={{ marginTop: '10px', padding: '10px', backgroundColor: '#fff', borderRadius: '3px', minHeight: '20px' }}>
        {status}
      </p>
    </div>
  );
}
